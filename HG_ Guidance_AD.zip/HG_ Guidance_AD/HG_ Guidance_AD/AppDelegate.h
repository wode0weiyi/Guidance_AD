//
//  AppDelegate.h
//  HG_ Guidance_AD
//
//  Created by 胡志辉 on 2017/6/5.
//  Copyright © 2017年 胡志辉. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

